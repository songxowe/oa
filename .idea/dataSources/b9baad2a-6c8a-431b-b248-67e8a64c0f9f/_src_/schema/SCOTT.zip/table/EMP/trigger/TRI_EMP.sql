CREATE TRIGGER TRI_EMP
BEFORE INSERT OR UPDATE OF JOB
  ON EMP
FOR EACH ROW
  begin
  if inserting then
    select upper(:new.job) into :new.job from dual;
    else
    select upper(:new.job) into :new.job from dual;
    end if;
  end;
/
