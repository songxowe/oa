CREATE TRIGGER TRI_DEPT
BEFORE DELETE
  ON DEPT
  begin
    raise_application_error(-20001,'禁止删除数据');
  end;
/
