CREATE VIEW V_EMPANDDEPT AS select e."EMPNO",e."ENAME",e."JOB",e."MGR",e."HIREDATE",e."SAL",e."COMM",e."DEPTNO",dname,loc from emp e join dept d
on e.deptno=d.deptno
/
