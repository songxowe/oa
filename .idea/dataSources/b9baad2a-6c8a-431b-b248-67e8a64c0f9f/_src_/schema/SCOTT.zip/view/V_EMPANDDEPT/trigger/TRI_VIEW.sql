-- Cannot generate trigger TRI_VIEW: the table is unknown
/
